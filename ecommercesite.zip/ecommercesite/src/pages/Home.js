import React from 'react';
import { Link } from 'react-router-dom';
import './Home.css';

function Home() {
  return (
    <div className="home">
      {/* Hero Section */}
      <div className="hero-section">
        <h1>Welcome to Our E-commerce Store</h1>
        <p>Find the best products at unbeatable prices.</p>
        <Link to="/products" className="shop-now-button">
          Shop Now
        </Link>
      </div>

      {/* Promotional Banners */}
      <div className="promotions">
        <div className="promotion-banner">
          <h2>Free Shipping on Orders Over $50!</h2>
          <p>Get your items delivered right to your door.</p>
        </div>
        <div className="promotion-banner">
          <h2>New Arrivals</h2>
          <p>Check out the latest additions to our collection.</p>
          <Link to="/products" className="view-products-button">
            View Products
          </Link>
        </div>
      </div>

      {/* Featured Products */}
      <div className="featured-products">
        <h2>Featured Products</h2>
        <div className="product-list">
          {/* Example of Featured Product Card */}
          <div className="product-card">
            <img src="https://via.placeholder.com/150" alt="Product" />
            <h3>Product Name</h3>
            <p className="price">$29.99</p>
            <Link to="/products/1" className="view-details-button">
              View Details
            </Link>
          </div>
          <div className="product-card">
            <img src="https://via.placeholder.com/150" alt="Product" />
            <h3>Another Product</h3>
            <p className="price">$39.99</p>
            <Link to="/products/2" className="view-details-button">
              View Details
            </Link>
          </div>
          {/* Add more featured products as needed */}
        </div>
      </div>
    </div>
  );
}

export default Home;

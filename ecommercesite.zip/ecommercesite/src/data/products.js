const products = [
    {
      id: 1,
      name: "Smartphone",
      price: 299,
      description: "A high-end smartphone with a stunning display and great camera.",
      image: "/images/smartphone.jpg",
    },
    {
      id: 2,
      name: "Laptop",
      price: 999,
      description: "A powerful laptop for work and gaming.",
      image: "/images/laptop.jpg",
    },
    // Add more products as needed
    {
      id: 3,
      name: "Mobile Phone",
      price: 999,
      description: "A powerful laptop for work and gaming.",
      image: "/images/laptop.jpg",
    },
    {
      id: 3,
      name: "Mobile Phone",
      price: 999,
      description: "A powerful laptop for work and gaming.",
      image: "/images/laptop.jpg",
    },
    {
      id: 3,
      name: "Mobile Phone",
      price: 999,
      description: "A powerful laptop for work and gaming.",
      image: "/images/laptop.jpg",
    },
    {
      id: 3,
      name: "Mobile Phone",
      price: 999,
      description: "A powerful laptop for work and gaming.",
      image: "/images/laptop.jpg",
    },
    {
      id: 3,
      name: "Mobile Phone",
      price: 999,
      description: "A powerful laptop for work and gaming.",
      image: "/images/laptop.jpg",
    },
  ];
  
  export default products;
  
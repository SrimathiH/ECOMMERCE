import React from "react";
import { Link } from "react-router-dom";
import { FaHome, FaShoppingCart } from "react-icons/fa"; // Import icons from React Icons
import "./Navbar.css";
import { AiFillProduct } from "react-icons/ai";

function Navbar() {
  return (
    <nav className="navbar">
      <div className="navbar-links">
        {/* Home Icon Link */}
        <Link to="/" className="navbar-link">
          <FaHome size={24} />
        </Link>

        {/* Cart Icon Link */}
        <Link to="/cart" className="navbar-link">
          <FaShoppingCart size={24} />
        </Link>

        {/* Product Icon Link */}
        <Link to="/products" className="navbar-link">
          <AiFillProduct size={24} />
        </Link>
      </div>
      <h1 className="navbar-title">AMAZON</h1>
    </nav>
  );
}

export default Navbar;
